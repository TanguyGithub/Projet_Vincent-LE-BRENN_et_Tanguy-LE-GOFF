Le dossier contient :

  - Le fichier .c : mainVersionFinale.c
  - Son header : mainVersionFinale.h
  - La fonction titreHTMLperson.c (pas intégrée au programme)
  - La fonction fichePath.c (pas intégrée au programme)
  - La fonction read_csv.c (pas intégrée au programme)
  - Les fichiers 40.csv et 200.csv

*******************************************************
La fonctionalité n°6 ne fonctionne pas car pas terminée
*******************************************************

Pour compiler : gcc mainVersionFinale.c -o prog.c
Pour lancer le programme : ./prog.c
